//
//  main.cpp
//  BinaryToString
//
//  Created by fang liao on 2023/7/10.
//

#include <iostream>
#include <fstream>
#include <vector>
#include "binary_strings.hpp"

int main(int argc, const char * argv[]) {
    // 打开二进制文件
    std::ifstream file("/Users/sjustfly/Desktop/a/crash", std::ios::binary);

    // 检查文件是否打开成功
    if (!file.is_open()) {
        std::cerr << "Failed to open binary file." << std::endl;
        return 1;
    }
    // 获取文件大小
    file.seekg(0, std::ios::end);
    std::streampos file_size = file.tellg();
    file.seekg(0, std::ios::beg);
    // 分配缓冲区
    std::vector<unsigned char> buffer(file_size);
    // 读取文件到缓冲区
    file.read(reinterpret_cast<char*>(buffer.data()), file_size);
    // 关闭文件
    file.close();
    // 将 vector 转换为 const unsigned char buffer[]
    const unsigned char *data_ptr = buffer.data();
    vector<std::tuple<string, string, std::pair<size_t, size_t>, bool>> results = extract_all_strings(data_ptr, buffer.size(), 4, false);

    std::string text = "";
    for (const auto& tuple : results) {
        const std::string& s = std::get<0>(tuple);
//        const std::string& s1 = std::get<1>(tuple);
//        std::pair<size_t, size_t> pos = std::get<2>(tuple);
        text = text + s;
    }
    std::cout << text << std::endl;
    return 0;
}
